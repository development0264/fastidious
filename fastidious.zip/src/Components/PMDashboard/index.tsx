import { Box, Button } from "@mui/material";
import Layout from "../Layout";

const PMDashboard = () => {
  return (
    <Layout title="Dashboard">
        <Box>
            
        </Box>
    </Layout>
  );
};

export default PMDashboard;

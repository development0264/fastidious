import { Box } from "@mui/material";
import Layout from "../Layout";

const Project = () => {
  return (
    <Layout>
      <Box>Project</Box>
    </Layout>
  );
};

export default Project;
